
public class MyInteger {
private int value;
	
	MyInteger(int value) {
		this.value = value;
	}
	
	public int getInteger() {
		return value;
	}
	
	public boolean isEven() {
		return isEven(value);
	}
	
	public boolean isOdd() {
		return isOdd(value);
	}
	
	public boolean isPrime() {
		return isPrime(value);
	}
	
	public static boolean isEven(int number) {
		if (number % 2 == 0) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public static boolean isOdd(int number) {
		if (number % 2 != 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean isPrime(int number) {
		boolean isItPrime = true;
		if (number <= 1) {
			isItPrime = false;
			return isItPrime;
		}
		else {
		for (int i = 2; i <= number/2; i++) {
			if((number % i) == 0) {
				isItPrime = false;
				break;
			}
		}
			return isItPrime;
		}
	}
	
	public static boolean isEven(MyInteger object) {
		return object.isEven();
	}
	
	public static boolean isOdd(MyInteger object) {
		return object.isOdd();
	}
	
	public static boolean isPrime(MyInteger object) {
		return object.isPrime();
	}
	
	public boolean equals(int number) {
		if (this.value == number) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean equals(MyInteger object) {
		if (object.value == this.value) {
			return true;
		}
		else {
			return false;
		}
	}
	public static int parseInt(char[] characters) {
		int value = 0;
		for (int i = 0, j = (int)Math.pow(10, characters.length - 1);  i < characters.length; i++, j /= 10) {
			value += (characters[i] - 48) * j;
		}
		return value;
	}
	
	 public static int parseInt(String str) {
				int value = 0;
				for (int i = 0, j = (int)Math.pow(10, str.length() - 1); i < str.length(); i++, j /= 10) {
					value += (str.charAt(i) - 48) * j;
				}
				return value;
			}
}
